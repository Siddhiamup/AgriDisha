<section class="hero-section fade-in">
    <div class="container text-center">
        <h1 class="hero-title">From farm to future,we lead the way</h1>
        <p class="hero-description">Empowering farmers and buyers for a sustainable agricultural ecosystem.</p>
        <button class="btn btn-primary btn-lg mt-3" onclick="window.location.href='registration.php';">Register as a
            Farmer</button>
    </div>
</section>